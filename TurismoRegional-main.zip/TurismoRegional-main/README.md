<p align = "center">
   <img src="https://i.imgur.com/2zsZF59.png">
<p>

## Sobre o projeto

Um site que mostra quatro pontos turísticos de cada região do Brasil. Um mapa SVG é usado como seletor para cada página.<br>Ícone do site e da logo retirados do site [VeryIcon](https://www.veryicon.com)

## Usagem e Instalação
Acesse o site clicando [aqui](https://gmozer.github.io/TurismoRegional/)<br>Você também pode clonar o repositório com o git ou baixar o código como RAR.

```bash
$ git clone https://github.com/gMozer/TurismoRegional.git
```
    
## Autores

- [@Belinaci](https://github.com/Belinaci)
- [@GabrielaOrtiz1](https://github.com/GabrielaOrtiz1)
- [@gMozer](https://www.github.com/gMozer)
- [@IsaPortugal](https://github.com/IsaPortugal)
- [@LeonardoPrestes05](https://github.com/LeonardoPrestes05)
- [@zRodrigoFerreira](https://github.com/zRodrigoFerreira)
